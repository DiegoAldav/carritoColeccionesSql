package Programa;

import colecciones.*;

import java.nio.file.Files;
import java.nio.file.Paths;

public class coleccionesProg {
    public static void main(String[] args) throws Exception {

        lecturaDeProductosSql Lsql = new lecturaDeProductosSql("jdbc:mysql://localhost:3306/diego_db", "root", null,"select * from productos");

        lecturaDeProductos LP = new lecturaDeProductos("/home/mustafa/trabajos/coleccionesSql3/productos.csv");

        ItemCarrito listaDeItems = new ItemCarrito(Lsql.getProductosSql());
        //ItemCarrito listaDeItems = new ItemCarrito(LP.getListaDeProductos());

        lecturaDeItems L1 = new lecturaDeItems("/home/mustafa/trabajos/coleccionesSql3/carritoC.csv");

        CarritoCompras c1 = new CarritoCompras();
        for (int i = 0; i < L1.getLecturaItems(listaDeItems).length; i++) {
            c1.agregarItem(L1.getLecturaItems(listaDeItems)[i]);
        }

        DescuentoFijo fijo1 = new DescuentoFijo("fijo", 250);

        DescuentoPorcentaje porc1 = new DescuentoPorcentaje("%",30);
        DescuentoPorcentajeConTope porcTope1 = new DescuentoPorcentajeConTope();
        porcTope1.setTipo("%");
        porcTope1.setValor(30);

        ImprimirTicket t1 = new ImprimirTicket();
        System.out.println(t1.imprimirTiket(c1,porcTope1));

        Files.writeString(Paths.get("/home/mustafa/trabajos/coleccionesSql3/ticket.txt" ), t1.imprimirTiket(c1,fijo1)+t1.imprimirTiket(c1,porc1) );

    }
}
