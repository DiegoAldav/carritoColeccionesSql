package colecciones;

public class DescuentoFijo extends  Descuento {

    public DescuentoFijo() {}

    public DescuentoFijo(String tipo, int valor) {
        this.setTipo(tipo);
        this.setValor(valor);
    }

    @Override
    public double getDescuento(int valorInicial) {
        return getValor();
    }
}
