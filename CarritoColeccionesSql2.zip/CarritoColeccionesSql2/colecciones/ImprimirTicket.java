package colecciones;

import java.time.LocalDateTime;

public class ImprimirTicket {

    int nro;
    String ticket;
    LocalDateTime fecha;

    public ImprimirTicket() {}

    public void setNro(int nro) {
        this.nro = nro;
    }

    public int getNro() {
        return nro;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getTicket() {
        return ticket;
    }
    public String getFechaActual() {
        String z = LocalDateTime.now().getDayOfMonth()+"/"+LocalDateTime.now().getMonth().getValue()+"/"+LocalDateTime.now().getYear();
        return z;
    }
    public String getHoraActual() {
        String b = LocalDateTime.now().getHour()+":"+LocalDateTime.now().getMinute()+":"+LocalDateTime.now().getSecond();
        return b;
    }


    public String imprimirTiket(CarritoCompras unCarrito, Descuento unDescuento) {
        String j = "";
        for (int i = 0; i < unCarrito.getItems().size(); i++) {
           j += "  "+unCarrito.getItems().get(i).getCantidad()+"      "+unCarrito.getItems().get(i).getProductPrecio()+"               "+unCarrito.getItems().get(i).getProductoNombre()+"\n";
        }

        String p = "------------------------------tiket compra----------------------------\n" +
                   " "+this.getHoraActual()+"                                                "+this.getFechaActual()+"\n"+
                   "                       super mercado ARGENCHINO\n"+
                   " cant.  precioUnitario    producto\n"+
                   ""+j+""+
                   "         precio Total:  "+unCarrito.getTotalSinDescuento()+"\n"+
                   "         - descuento de "+unDescuento.getValor()+" "+unDescuento.getTipo()+", aplicado al total es "+unDescuento.getDescuento(unCarrito.getTotalSinDescuento())+"\n"+
                   "         * Total con descuento: "+unCarrito.getTotalConDescuento(unDescuento)+"\n"+
                   "-------------------------gracias por su compra------------------------\n";

    return p;
    }
}
