package colecciones;

public abstract class Descuento {
    private String tipo;
    private int valor;

    public Descuento () {
    }
    public Descuento(String  tipo, int valor) {
        this.tipo = tipo;
        this.valor = valor;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public abstract double getDescuento(int valorInicial);

}
