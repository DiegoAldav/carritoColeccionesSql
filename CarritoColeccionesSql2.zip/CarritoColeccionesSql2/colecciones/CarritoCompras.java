package colecciones;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CarritoCompras {

    List<ItemCarrito> items;

    public CarritoCompras() {
        this.items = new ArrayList<ItemCarrito>();
    }

    public void agregarItem(ItemCarrito unItem) {
        this.items.add(unItem);
    }

    public void quitarItem(ItemCarrito unItem) {
        this.items.remove(unItem);
    }

    public List<ItemCarrito> getItems() {
        return items;
    }


    public int getCantidadProductosComprados() {
        return items.size();
    }

    public int getTotalSinDescuento() {
        int total = 0;
        for (int i = 0; i < items.size(); i++) {
            total += items.get(i).getPrecioCxP();
        }
        return total;
    }
    public double getTotalConDescuento(Descuento unDescuento) {
        int total = 0;
        for (int i = 0; i < items.size(); i++) {
            total += items.get(i).getPrecioCxP();
        }
        return total - unDescuento.getDescuento(total);
    }

    public double getPrecioFinalSinDescuentoZZZ() {
        double precioFinal = 0;
        for (ItemCarrito item : this.items) {
            double precioItem = item.getPrecioCxP();
            precioFinal += precioItem;
        }
        return precioFinal;
    }

public double getPrecioFinalSinDescuentoXXX() {
        double precioFinal = 0.0;
    Iterator<ItemCarrito> iterator = this.items.iterator();
    while (iterator.hasNext()) {
        ItemCarrito item = iterator.next();
        double precioItem = item.getPrecioCxP();
        precioFinal += precioItem;
    }
    return precioFinal;
}

    public double getPrecioFinalYYY() {
        double precioFinal;
        precioFinal = this.items.stream().mapToDouble(item -> item.getPrecioCxP()).map(precio -> precio).sum();
        return precioFinal;
    }
}
