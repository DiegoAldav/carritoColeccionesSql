package colecciones;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class lecturaDeProductosSql {

    private String url;
    private String usuario;
    private String contrasenia;
    private String consulta;

    public lecturaDeProductosSql() {
    }

    public lecturaDeProductosSql(String url, String usuario, String contrasenia, String consulta) {
        this.url = url;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.consulta = consulta;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setConsulta(String consulta) {
        this.consulta = consulta;
    }

    public String getConsulta() {
        return consulta;
    }

    public Producto[] getProductosSql() {

        List<String> idProductos = new ArrayList<>();
        try {
            // registrar la clase del driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // armar la coneccion
            Connection conexion = DriverManager.getConnection(this.getUrl(), this.getUsuario(), this.contrasenia);
            //Connection conexion= DriverManager.getConnection(conexiondb, usuariodb, contraseniadb);

            // crear una sentencia para las consultas
            Statement sentencia = conexion.createStatement();

            // realizar consulta
            ResultSet productosSql = sentencia.executeQuery(this.getConsulta());
            //ResultSet pronosticosql= sentencia.executeQuery(consultadb);

            while (productosSql.next()) {

                String p = productosSql.getString(1) + "," + productosSql.getString(2) + "," + productosSql.getString(3);
                idProductos.add(p);

                //System.out.println(p);

            }

        } catch (Exception e) {
            System.out.println(e);
            System.out.println("\nno se puede conectar a la base de datos en sql o falta la tabla de productos en mysql");
            System.exit(0);
        }

        idProductos.remove(0);

        Producto[] listaDeProductos = new Producto[idProductos.size()];
        for (int i = 0; i < idProductos.size(); i++) {
            String[] prod = idProductos.get(i).split(",");
            int prec = Integer.parseInt(prod[1]);
            int cod = Integer.parseInt((prod[2]));
            listaDeProductos[i] = new Producto(prod[0], prec, cod);

        }
        return listaDeProductos;
    }
}
