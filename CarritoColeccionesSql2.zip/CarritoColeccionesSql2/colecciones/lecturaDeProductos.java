package colecciones;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class lecturaDeProductos {

    private String dirDeProd;

    public lecturaDeProductos() {}

    public  lecturaDeProductos(String unaDireccionDeProductos){
        this.dirDeProd = unaDireccionDeProductos;
    }

    public void setDirDeProd(String dirDeProd) {
        this.dirDeProd = dirDeProd;
    }

    public String getDirDeProd() {
        return dirDeProd;
    }

    public Producto[] getListaDeProductos() throws Exception {

        String archivoProd = getDirDeProd();

        File result = new File(archivoProd);
        if (!result.exists()) {
            System.out.println("no encuentra el archivo productos.csv\npuede que la direccion del archivo esta mal\no puede que el archivo no exista");
            System.exit(0);
        }

        List<String> productosCodigos = Files.readAllLines(Paths.get(archivoProd));
        productosCodigos.remove(0);

        Producto[] listaDeProductos = new Producto[productosCodigos.size()];
        for (int i = 0; i < productosCodigos.size(); i++) {
            String[] prod = productosCodigos.get(i).split(",");
            int prec = Integer.parseInt(prod[1]);
            int cod = Integer.parseInt((prod[2]));
            listaDeProductos[i] = new Producto(prod[0],prec,cod);
        }
        return listaDeProductos;
    }

}
