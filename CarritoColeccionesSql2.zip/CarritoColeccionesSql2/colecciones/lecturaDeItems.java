package colecciones;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class lecturaDeItems  {

    String archivo;

    public lecturaDeItems() {}

    public lecturaDeItems(String unaDireccion) {
        this.archivo = unaDireccion;
    }

    public void setArchivo(String archivo) {
        this.archivo = archivo;
    }

    public String getArchivo() {
        return archivo;
    }

    public ItemCarrito[] getLecturaItems(ItemCarrito unaListaDeItems) throws Exception {

        File result = new File(archivo);
        if (!result.exists()) {
            System.out.println("no encuentra el archivo carrrito.csv\npuede que la direccion del archivo esta mal\no puede que el archivo no exista");
            System.exit(0);
        }

        List<String> carritoCodigos = Files.readAllLines(Paths.get(archivo));
        carritoCodigos.remove(0);
        ItemCarrito[] it = new ItemCarrito[carritoCodigos.size()];

        for (int i = 0; i < carritoCodigos.size(); i++) {
            String[] art = carritoCodigos.get(i).split(",");
            Producto prod;
            int a = Integer.parseInt(art[0]);
            int b = Integer.parseInt(art[1]);
                prod = unaListaDeItems.getProductoCodigo(b);
            it[i]  = new ItemCarrito(a, prod);
        }
        return it;
    }
}
