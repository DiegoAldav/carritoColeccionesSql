package colecciones;

public class DescuentoPorcentaje extends Descuento {

    public DescuentoPorcentaje() {}

    public DescuentoPorcentaje(String tipo,int valor) {
        this.setTipo(tipo);
        this.setValor(valor);
    }

    @Override
    public double getDescuento(int valorInicial) {
        return valorInicial * getValor()/100;
    }
}
