package colecciones;

public class ItemCarrito {
    private int cantidad;
    private Producto producto;
    private Producto[] productos;


    public ItemCarrito() {}

    public ItemCarrito(int cantidad, Producto producto) {
        this.cantidad = cantidad;
        this.producto = producto;
    }
    public ItemCarrito(Producto[] productos) {
        this.productos = productos;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getProductPrecio() {
        return producto.getPrecio();
    }
    public  String getProductoNombre() {
        return producto.getNombre();
    }

    public int getPrecioCxP() {
        return this.getCantidad() * this.producto.getPrecio();
    }

    public Producto getProductoCodigo(int unCodigo) {
        Producto prod = new Producto();
        for (int i = 0; i < productos.length; i++) {
            if (productos[i].getCodigo() == unCodigo) {
                prod = productos[i];
            }
        }
        return prod;
    }
}
