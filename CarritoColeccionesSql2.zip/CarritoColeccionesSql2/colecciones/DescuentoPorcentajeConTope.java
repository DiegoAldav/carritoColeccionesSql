package colecciones;

public class DescuentoPorcentajeConTope extends DescuentoPorcentaje{

    @Override
    public double getDescuento(int valorInicial) {
        double tope = 0;
        if ((valorInicial * getValor()/100) > 1500) {
            tope = 1500;
        } else {
            tope = valorInicial *getValor()/100;
        }
        return tope;
    }
}

